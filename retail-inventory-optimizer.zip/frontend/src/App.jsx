import React from 'react';
import InventoryDashboard from './components/InventoryDashboard';

function App() {
  return <InventoryDashboard />;
}

export default App;